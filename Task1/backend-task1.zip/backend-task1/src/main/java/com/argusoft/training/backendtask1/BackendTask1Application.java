package com.argusoft.training.backendtask1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendTask1Application {

	public static void main(String[] args) {
		SpringApplication.run(BackendTask1Application.class, args);
	}

}
