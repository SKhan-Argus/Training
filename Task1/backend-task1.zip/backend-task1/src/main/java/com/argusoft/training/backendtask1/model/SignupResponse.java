package com.argusoft.training.backendtask1.model;

import lombok.Data;

@Data
public class SignupResponse {
    private boolean success;
    private String message;
}
